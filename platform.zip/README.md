
  # User Personas and Flows

  This is a code bundle for User Personas and Flows. The original project is available at https://www.figma.com/design/xMymldCPpCW3tJFHov6JfO/User-Personas-and-Flows.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  